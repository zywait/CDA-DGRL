
import pandas as pd
import numpy as np
node_features = pd.read_csv('../data/AllNodeAttribute64.csv', header=None)
node_features


node_features = node_features.iloc[:, 1:]
print(node_features.shape)

DTIs= pd.read_csv('../data/CircRNADiseaseNum.csv', header=None)
DTIs


Nindex = pd.read_csv('circRNANewRandomList.csv', header=None)
labels = pd.read_csv('labels.csv')

def load_file_as_Adj_matrix(filename):
    import scipy.sparse as sp
    DTIs_train = pd.read_csv(filename, header=None)
    if max(DTIs_train[1]) != 672:
        relation_matrix = np.zeros((672 + 1, 672 + 1))
    else:
        relation_matrix = np.zeros((max(DTIs_train[1] + 1), max(DTIs_train[1] + 1)))
    for i, j in np.array(DTIs_train):
        lnc, mi = int(i), int(j)
        relation_matrix[lnc, mi] = 1
    Adj = sp.csr_matrix(relation_matrix, dtype=np.float32)
    return Adj

def load_data(adj, node_features, node_labels):
    features = sp.csr_matrix(node_features, dtype=np.float32)
    features = normalize(features)
    adj = normalize(adj + sp.eye(adj.shape[0]))
    idx_train = range(500)
    idx_val = range(500, 660)
    idx_test = range(660, int(adj.shape[0]))
    features = torch.FloatTensor(np.array(features.todense()))
    labels = torch.LongTensor(np.array(node_labels))
    adj = sparse_mx_to_torch_sparse_tensor(adj)
    idx_train = torch.LongTensor(idx_train)
    idx_val = torch.LongTensor(idx_val)
    idx_test = torch.LongTensor(idx_test)
    return adj, features, labels, idx_train, idx_val, idx_test

def normalize(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx

def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels)


def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """
    numpy中的ndarray转化成pytorch中的tensor : torch.from_numpy()
    pytorch中的tensor转化成numpy中的ndarray : numpy()
    """
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)


import torch
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module


class GraphConvolution(Module):
    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input, adj):
        support = torch.mm(input, self.weight)
        output = torch.spmm(adj, support)
        if self.bias is not None:
            return output + self.bias
        else:
            return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'


# %%

import torch.nn as nn
import torch.nn.functional as F

class GCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(GCN, self).__init__()
        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, nclass)
        self.dropout = dropout
        self.weight = Parameter(torch.FloatTensor(nfeat, nhid))

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x2 = F.dropout(x, self.dropout, training=self.training)
        x2 = self.gc2(x2, adj)
        return F.log_softmax(x2, dim=1), x2


# %%

import numpy

print(numpy.__version__)

# Training settings
learning_rate = 0.01
weight_decay = 10e-4
epoch_num = 200
dropout = 0.5
hi_size = 64

name = locals()
dd = pd.DataFrame(np.random.randint(0, 1, node_features.shape[0]))
dd['index'] = dd.index
dd



import scipy.sparse as sp
import pandas as pd
import numpy as np
creat_var = locals()
creat_var = locals()
Negative = pd.read_csv('circRNANegativeSample.csv', header=None)
Nindex = pd.read_csv('circRNANewRandomList.csv', header=None)
Negative[2] = Negative.apply(lambda x: 0 if x[0] < 0 else 0, axis=1)
Embedding_GCN = pd.read_csv('Emdebding_GCN.csv', header=None)
Embedding_Node2vec = pd.read_csv('../node2vec/125.txt', sep=' ', header=None)
Embedding_Node2vec = Embedding_Node2vec.sort_values(0, ascending=True)
Embedding_Node2vec.set_index(0, inplace=True)
Embedding_Node2vec['index'] = Embedding_Node2vec.index
Embedding = pd.merge(dd, Embedding_Node2vec, how='left', on='index')
Embedding = Embedding.fillna(int(0)).iloc[:, 2:]
for i in range(5):
    data_train_feature, data_test_feature = [], []

    train_data = pd.read_csv('DTIs_train' + str(i) + '.csv', header=None)
    train_data[2] = train_data.apply(lambda x: 1 if x[0] < 0 else 1, axis=1)
    kk = []
    for j in range(5):
        if j != i:
            kk.append(j)
    index = np.hstack(
        [np.array(Nindex)[kk[0]], np.array(Nindex)[kk[1]], np.array(Nindex)[kk[2]], np.array(Nindex)[kk[3]]])
    result = train_data.append(pd.DataFrame(np.array(Negative)[index]))
    labels_train = result[2]
    for r in range(len(result)):
        data_train_feature.append(
            np.hstack([np.hstack([np.array(Embedding_GCN)[result.iloc[r, 0]], np.array(Embedding)[result.iloc[r, 0]]]),
                       np.hstack(
                           [np.array(Embedding_GCN)[result.iloc[r, 1]], np.array(Embedding)[result.iloc[r, 1]]])]))

    creat_var['data_train' + str(i)] = data_train_feature
    creat_var['labels_train' + str(i)] = labels_train
    print(len(labels_train))
    del labels_train, result, data_train_feature, r
    test_data = pd.read_csv('DTIs_test' + str(i) + '.csv', header=None)
    test_data[2] = test_data.apply(lambda x: 1 if x[0] < 0 else 1, axis=1)
    result = test_data.append(pd.DataFrame(np.array(Negative)[np.array(Nindex)[i]]))
    labels_test = result[
        2]  # np.hstack([np.array(Embedding_GCN)[result.iloc[x,0]],np.array(Embedding_Node2vec)[result.iloc[x,0]]])
    for x in range(len(
            result)):  # np.hstack([np.array(Embedding_GCN)[result.iloc[x,1]],np.array(Embedding_Node2vec)[result.iloc[x,1]]])
        data_test_feature.append(
            np.hstack([np.hstack([np.array(Embedding_GCN)[result.iloc[x, 0]], np.array(Embedding)[result.iloc[x, 0]]]),
                       np.hstack(
                           [np.array(Embedding_GCN)[result.iloc[x, 1]], np.array(Embedding)[result.iloc[x, 1]]])]))

    creat_var['data_test' + str(i)] = data_test_feature
    creat_var['labels_test' + str(i)] = labels_test
    print(len(labels_test))
    del train_data, test_data, labels_test, result, data_test_feature, x  # , Embedding_Node2vec, Embedding, Embedding_GCN
    print(i)

# %%

data_train = [data_train0, data_train1, data_train2, data_train3, data_train4]
data_test = [data_test0, data_test1, data_test2, data_test3, data_test4]
labels_train = [labels_train0, labels_train1, labels_train2, labels_train3, labels_train4]
labels_test = [labels_test0, labels_test1, labels_test2, labels_test3, labels_test4]
print(np.array(data_train0).shape)
print(np.array(data_test0).shape)
print(np.array(labels_train0).shape)
print(np.array(labels_test0).shape)

import math

def MyConfusionMatrix(y_real, y_predict):
    from sklearn.metrics import confusion_matrix
    CM = confusion_matrix(y_real, y_predict)
    print(CM)
    CM = CM.tolist()
    TN = CM[0][0]
    FP = CM[0][1]
    FN = CM[1][0]
    TP = CM[1][1]
    print('TN:%d, FP:%d, FN:%d, TP:%d' % (TN, FP, FN, TP))
    Acc = (TN + TP) / (TN + TP + FN + FP)
    Sen = TP / (TP + FN)
    Spec = TN / (TN + FP)
    Prec = TP / (TP + FP)
    MCC = (TP * TN - FP * FN) / math.sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN))

    print('Acc:', round(Acc, 4))
    print('Sen:', round(Sen, 4))
    print('Spec:', round(Spec, 4))
    print('Prec:', round(Prec, 4))
    print('MCC:', round(MCC, 4))
    Result = []
    Result.append(round(Acc, 4))
    Result.append(round(Sen, 4))
    Result.append(round(Spec, 4))
    Result.append(round(Prec, 4))
    Result.append(round(MCC, 4))
    return Result


def MyAverage(matrix):
    SumAcc = 0
    SumSen = 0
    SumSpec = 0
    SumPrec = 0
    SumMcc = 0
    counter = 0
    while counter < len(matrix):
        SumAcc = SumAcc + matrix[counter][0]
        SumSen = SumSen + matrix[counter][1]
        SumSpec = SumSpec + matrix[counter][2]
        SumPrec = SumPrec + matrix[counter][3]
        SumMcc = SumMcc + matrix[counter][4]
        counter = counter + 1
    print('AverageAcc:', SumAcc / len(matrix))
    print('AverageSen:', SumSen / len(matrix))
    print('AverageSpec:', SumSpec / len(matrix))
    print('AveragePrec:', SumPrec / len(matrix))
    print('AverageMcc:', SumMcc / len(matrix))
    return


def MyStd(result):
    import numpy as np
    NewMatrix = []
    counter = 0
    while counter < len(result[0]):
        row = []
        NewMatrix.append(row)
        counter = counter + 1
    counter = 0
    while counter < len(result):
        counter1 = 0
        while counter1 < len(result[counter]):
            NewMatrix[counter1].append(result[counter][counter1])
            counter1 = counter1 + 1
        counter = counter + 1
    StdList = []
    MeanList = []
    counter = 0
    while counter < len(NewMatrix):
        # std
        arr_std = np.std(NewMatrix[counter], ddof=1)
        StdList.append(arr_std)
        # mean
        arr_mean = np.mean(NewMatrix[counter])
        MeanList.append(arr_mean)
        counter = counter + 1
    result.append(MeanList)
    result.append(StdList)
    # 换算成百分比制
    counter = 0
    while counter < len(result):
        counter1 = 0
        while counter1 < len(result[counter]):
            result[counter][counter1] = round(result[counter][counter1] * 100, 2)
            counter1 = counter1 + 1
        counter = counter + 1
    return result


from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix
import joblib
from sklearn.model_selection import cross_val_score

import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve
from sklearn.metrics import auc
from scipy import interp
import time

from sklearn.metrics import precision_recall_curve,average_precision_score
now = time.strftime("%Y-%m-%d-%H_%M_%S", time.localtime(time.time()))


k_range = [301, 401, 501, 601, 701, 801, 901, 999]
cv_scores = []
for n in k_range:
    print('n_estimators: %d '%(n))
    # RandomF = RotationForest(n_classifiers=n)
    RandomF = GaussianNB(priors=None)
    scores = cross_val_score(RandomF,data_train, labels_train,
                             cv=5,
                             scoring='roc_auc',
                             n_jobs=-1)
    cv_scores.append(scores.mean())
print("best_n_neighbors is：", k_range[cv_scores.index(max(cv_scores))])

tprs = []
aucs = []
mean_fpr = np.linspace(0, 1, 1000)

recalls = []
auprs = []
mean_precision = np.linspace(0, 1, 1000)

colorlist = ['red', 'gold', 'purple', 'green', 'blue', 'black']

AllResult = []
plt.figure(figsize=(20, 10))

for i in range(5):

    X_train, X_test = data_train[i], data_test[i]
    Y_train, Y_test = np.array(labels_train[i]), np.array(labels_test[i])

    best_RandomF = GaussianNB(priors=None)

    best_RandomF.fit(np.array(X_train), np.array(Y_train))

    joblib.dump(best_RandomF, 'RandomF' + str(i) + '.pkl')

    y_score0 = best_RandomF.predict(np.array(X_test))
    y_score_RandomF = best_RandomF.predict_proba(np.array(X_test))

    print(confusion_matrix(Y_test, y_score0))  # , labels=[1,0]

    dd = np.vstack([Y_test, y_score_RandomF[:, 1]]).T
    RandomF_data = pd.DataFrame(dd)
    RandomF_data.to_csv('RandomF_' + str(i) + 'Prob.csv', header=False, index=False)
    fs = 20
    plt.subplot(1, 2, 1)

    fpr, tpr, thresholds = roc_curve(Y_test, y_score_RandomF[:, 1])

    tprs.append(interp(mean_fpr, fpr, tpr))
    tprs[-1][0] = 0.0

    roc_auc = auc(fpr, tpr)
    aucs.append(roc_auc)
    plt.plot(fpr, tpr, lw=1.5, alpha=0.8, color=colorlist[i],
             label='ROC fold %d(AUC=%0.4f)' % (i, roc_auc))
    plt.subplot(1, 2, 2)
    precision, recall, _ = precision_recall_curve(Y_test, y_score_RandomF[:, 1])
    recalls.append(interp(mean_precision, precision, recall))
    recalls[-1][-1] = 0.0
    roc_aupr = auc(recall, precision)
    auprs.append(roc_aupr)

    plt.plot(precision, recall, lw=1.5, alpha=0.8, color=colorlist[i],
             label='PR fold %d(AUPR=%0.4f)' % (i, roc_aupr))

    print("---------------------------------------------\n")
    print("fold = ", i)
    print("---------------------------------------------\n")
    Result = MyConfusionMatrix(Y_test, y_score0)
    AllResult.append(Result)
    AllResult[i].append(roc_auc)
    i += 1


MyAverage(AllResult)

MyNew = MyStd(AllResult)

df = pd.DataFrame(data=MyNew)
df.to_csv('RandomF_5-fold.csv', encoding='utf-8', header=None, index=False)
fs=20
plt.rcParams['font.sans-serif']=['SimSun']

plt.rcParams.update({"font.size":fs})
plt.subplot(1,2,1)

# 画对角线
plt.plot([0, 1], [0, 1], linestyle='--', lw=2, color='rosybrown', alpha=0.8)

mean_tpr = np.mean(tprs, axis=0)
mean_tpr[-1] = 1.0
mean_auc = auc(mean_fpr, mean_tpr)
std_auc = np.std(aucs, axis=0)
plt.plot(mean_fpr, mean_tpr, color=colorlist[i], label=r'Mean ROC (AUPR=%0.4f+-%0.4f)' % (mean_auc,std_auc), lw=2, alpha=1)
std_tpr = np.std(tprs, axis=0)
dataframe = pd.DataFrame({'roc_fpr': mean_fpr, 'roc_tpr': mean_tpr})
dataframe.to_csv('GaussianNBroc.csv', index=True, sep=',')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC curve')
plt.legend(loc='lower right')
plt.tick_params(labelsize=fs)

plt.subplot(1,2,2)
plt.plot([0,1], [1,0], linestyle='--', lw=2, color='rosybrown', alpha=0.8)
mean_recall = np.mean(recalls, axis=0)
mean_recall[-1] = 0.0
mean_aupr = auc(mean_precision,mean_recall)
std_aupr = np.std(auprs, axis=0)
plt.plot(mean_precision,mean_recall, color=colorlist[i], label=r'Mean AUPR (AUPR=%0.4f+-%0.4f)' % (mean_aupr,std_aupr), lw=2, alpha=1)
std_recall = np.std(recalls, axis=0)
dataframe = pd.DataFrame({'recall': mean_recall, 'precision': mean_precision})
dataframe.to_csv('GaussianNBpr.csv', index=True, sep=',')
plt.xlabel('Recall')
plt.ylabel('Predision')
plt.title('PR curve')

plt.tick_params(labelsize=fs)
plt.legend()
plt.xlim([-0.05, 1.05])
plt.ylim([-0.05, 1.05])
plt.tight_layout()
plt.savefig(now + 'RandomF_ROC.pdf')
plt.show()
